import sqlite3

def get_user(user_id):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = " + user_id)  # SQL injection vulnerability
    user = cursor.fetchone()
    conn.close()
    return {"user": user}

def create_user(data):
    return {"msg": "User created", "data": data}

from flask import Blueprint, request
from services.user_services import get_user, create_user

user_routes = Blueprint("users", __name__)

@user_routes.get("/user/<user_id>")
def user_details(user_id):
    return get_user(user_id)

@user_routes.post("/user")
def user_create():
    data = request.json
    return create_user(data)
